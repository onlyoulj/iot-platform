# iot-platform MQTT 协议参考（设备端视角）

来源：`E:\iot-platform\docs\MQTT.md`、`server/services/mqtt.js`、`server/services/device-info.js`、`server/routes/subscribe.js`。协议变更以平台侧代码为准。

## 1. 连接信息

| 项 | 值 |
| --- | --- |
| 明文入口（快速联调） | `129.204.31.17:1883` |
| TLS 入口（生产） | `i07bb631.ala.cn-shenzhen.emqxsl.cn:8883`，需 EMQX Cloud CA 证书 |
| WebSocket | 端口 8084（路径 `/mqtt`），小程序用 |
| MQTT 客户端凭据 | 用户名 `os` / 密码 `os` |
| EMQX Dashboard | `admin`/`Password1234`（仅网页，与 MQTT 连接无关） |
| REST API | appid `bc91151e` + app-secret（仅服务器端使用，设备端无关） |

三套认证互不通用。EMQX Cloud **Serverless** REST API 分页参数是 `_page`/`_limit`（带下划线前缀）。

## 2. 主题约定

| 方向 | 主题 | 用途 |
| --- | --- | --- |
| 设备订阅 | `device/{id}/downlink` | 接收指令（服务器同时向 `{id}` 与 `{device_name}` 两主题发布） |
| 设备发布 | `device/{id}/uplink` | 升级进度 `upgrade_status` / 心跳 `heartbeat` |
| 设备发布 | `device/{id}/info` | 设备信息（字段全可选） |

`{id}` = 平台数字 ID 或 DeviceName(SN)。服务器订阅 `device/+/uplink`、`device/+/info`（新增上行主题必须同时进 `mqtt.js` 的 UPLINK_TOPICS 并注册 handler，只做后者消息不会到达）。

## 3. 下行信封（服务器 → 设备）

```json
{ "type": "upgrade|control|test|...", "timestamp": "ISO8601", "data": { ... } }
```

### upgrade（OTA）

```json
{
  "type": "upgrade",
  "data": {
    "task_id": "OTA-20261013-001", "task_name": "...",
    "firmware_id": 3, "target_version": "v2.1.0", "strategy": "immediate",
    "retry": 3, "timeout": 300,
    "firmware": {
      "id": 3, "name": "...", "version": "v2.1.0", "md5": "...",
      "file_size": "4.2 MB",
      "download_url": "http://<平台>/api/subscribe/9/download?token=xxxx",
      "direct_url": "http://<平台>/uploads/firmware/xxx.bin"
    }
  }
}
```

- `download_url` 带鉴权（推荐），token = HMAC-SHA256(SUBSCRIBE_SECRET, 'device:'+id) 前 16 位；`direct_url` 静态直链。
- 平台只下发 `status='published'` 的最高版本固件；设备版本更高时不降级。
- `file_size` 是字符串，注意不要当数字解析。

### control（控制指令）

`data.action`：如 `reboot`（附 `delay` 秒数）及自定义动作。

### test

管理端「测试消息」按钮，data 内容不定，设备端日志回显即可。

## 4. 上行报文（设备 → 服务器）

### heartbeat → `device/{id}/uplink`

```json
{ "type": "heartbeat", "data": { "firmware_version": "v2.1.0" } }
```

平台行为：刷新 `last_online` 与在线状态；带 `firmware_version` 时同步设备档案。**平台 DEVICE_OFFLINE_TIMEOUT 当前 60s**，心跳周期必须小于它。

### upgrade_status → `device/{id}/uplink`

```json
{ "type": "upgrade_status", "data": { "task_id": "...", "status": "upgrading|success|failed", "progress": 45, "error_msg": "" } }
```

平台行为：`upgrading` 更新进度；`success` 更新设备固件版本并重算任务统计；`failed` 记入失败清单并创建告警。

### info → `device/{id}/info`（顶层字段，不包信封；也兼容 `{type:'info',data:{...}}`）

```json
{
  "battery": 85,              // 0-100；兼容 0-1 小数（自动×100）。别名 bat/power
  "signal": -65,              // dBm 负值；兼容 0-100 质量百分比（自动映射 dBm）。别名 rssi/csq
  "mac": "AA:BB:CC:DD:EE:FF", // 别名 mac_address
  "hardware_version": "HW-1.2.0", // 别名 hw_version/hardware
  "firmware_version": "v2.1.0",   // 别名 fw_version
  "longitude": 112.938814,    // 别名 lng/lon
  "latitude": 28.228209,      // 别名 lat
  "location": "可选；不传且经纬度存在时自动生成"
}
```

平台行为：逐字段归一化落库（电量夹取 0-100、经纬度越界丢弃）；**视为在线心跳**（`fault` 状态保持不掩盖故障）。设备端没有 MQTT 时可用 HTTP 兜底：`POST /api/subscribe/:key/info?token=<订阅token>`。

## 5. 平台推送机制（了解即可）

三层互补：① 服务器 MQTT 长连接优先；② 失败走 EMQX REST API publish（`MQTT_REST_FALLBACK` 热更新开关）；③ SSE/订阅轮询补推。OTA 任务对离线设备上线时经 mqtt-repush 防抖补推（带版本检查与次数上限）。因此设备**即使漏收 MQTT 指令，轮询订阅接口也能兜底拿到 `pending_upgrades`**。

## 6. ESP-IDF / ESP32-S3 踩坑

- **clientId 唯一**：EMQX 相同 clientId 互踢，量产设备必须拼 MAC/序列号。
- **TLS**：`mbedtls` 无系统 CA，8883 必须内嵌 CA 证书（EMBED_TXTFILES），否则握手失败；`broker.verification.certificate` 接 PEM 文本。
- **大报文分片**：esp-mqtt 收缓冲默认 1024 字节，升级指令信封可超；组件已设 3072 并实现分片重组，自定义实现时必须处理 `current_data_len < total_data_len`。
- **凭据错误的现象**：TCP 连上后立刻被断开（MQTT 0x04/0x05 return code），日志表现为 `TCP_TRANSPORT_CONNECT_FAILED`。
- **回调上下文**：esp-mqtt 事件回调运行在客户端任务，阻塞会拖垮心跳与重连；解析后经 queue 转业务任务。
- **心跳不要用 MQTT LWT 承载离线**：平台用 last_online 超时判离线，LWT 离线报文（type=offline）平台不识别，反而可能被当作心跳刷新在线。
- **ESP32-S3-N16R8**：16MB Flash + 8MB 八线 PSRAM，MQTT 模块本身不需要 PSRAM；如业务需要，`sdkconfig` 里开 Octal PSRAM（`CONFIG_SPIRAM_MODE_OCT`）。
