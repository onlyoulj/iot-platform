---
name: esp32-mqtt
description: ESP32（ESP-IDF 框架）设备端接入 iot-platform 平台 MQTT（EMQX）的技能。当用户要在 ESP32/ESP32-S3 上开发 MQTT 下行指令订阅、心跳保活、设备信息上报、OTA 升级状态上报，或要使用/修改 iot-platform 的 esp32/components/app_mqtt 组件（app_mqtt.c/app_mqtt.h），或排查 ESP32 连接 EMQX/收发消息问题时使用本技能。涵盖连接凭据、主题约定、消息信封格式、TLS/CA 配置与常见踩坑。
agent_created: true
---

# ESP32 MQTT（iot-platform / EMQX）

## Overview

在 ESP-IDF 框架的 ESP32 设备上完成与 iot-platform 平台（EMQX broker）的 MQTT 双向对接：订阅下行指令（upgrade/control/test 等）、周期心跳、设备信息上报与 OTA 升级状态上报。现成组件位于 `E:\iot-platform\esp32\components\app_mqtt\`（app_mqtt.c / include/app_mqtt.h / CMakeLists.txt / README.md），直接复用，不要从零重写。

## 何时使用

- 用户要把 ESP32（如 ESP32-S3-N16R8）设备通过 MQTT 接入 iot-platform；
- 用户要在 ESP-IDF 工程中集成/修改 app_mqtt 组件；
- ESP32 与 EMQX 连接或收发消息的排查。

## 标准接入流程

1. **拷贝组件**：把 `E:\iot-platform\esp32\components\app_mqtt\` 整目录复制到目标工程的 `components/` 下（依赖 json / mqtt / esp_timer 由组件 CMakeLists 自动声明，无需改工程配置）。
2. **初始化**：`app_mqtt_init(&cfg)`——`cfg.device_id` 必填（平台数字 ID 或 DeviceName/SN，二者可同时填以订阅两个下行主题）；其余字段 0/NULL 时自动取默认值（明文 `129.204.31.17:1883`、凭据 `os`/`os`、心跳 30s、keepalive 60s）。
3. **注册下行分发**：`app_mqtt_on("upgrade", cb)`、`app_mqtt_on("control", cb)`、`app_mqtt_on(NULL, cb)`（兜底）。回调在 MQTT 客户端任务上下文运行，**禁止阻塞**；OTA 下载等长操作必须转发到自有任务。
4. **启动**：`app_mqtt_start()`——自动重连（5s）、连上自动重订阅 + 立即心跳、周期心跳。
5. **上报**：`app_mqtt_report_info(&info)`（设备信息）、`app_mqtt_report_upgrade_status(...)`（OTA 进度）、`app_mqtt_publish_heartbeat()`（手动心跳）。

TLS 生产配置（8883 + 域名 + 内嵌 CA）、示例代码、API 全表见组件内 `README.md`。

## 硬性约束（违反即功能异常）

- **心跳周期必须 < 平台离线超时（当前 60s）**，组件默认 30s，不要调大。
- **clientId 必须全局唯一**（重复互踢下线）——组件已自动拼 MAC 后缀，自定义时保留该策略。
- **MQTT 客户端凭据是 `os`/`os`**，不是 EMQX Dashboard 账号（admin），也不是 REST API 的 appid/app-secret。
- **主题**：下行 `device/{id}/downlink`（服务器同时向 `{id}` 和 `{SN}` 两主题发布）；上行 `device/{id}/uplink`；信息 `device/{id}/info`。**服务端只订阅 `device/+/uplink` 与 `device/+/info`**，若需新增上行主题，必须同步修改 iot-platform 的 `server/services/mqtt.js`（UPLINK_TOPICS + handler）。
- **消息信封**统一为 `{"type":"...","timestamp":"...","data":{...}}`；info 主题例外，直接发布顶层字段对象。
- **服务器侧新增下行 type** 只需管理端发布，设备端用兜底回调（`app_mqtt_on(NULL, cb)`）即可前向兼容。

## 排查

| 现象 | 处理 |
| --- | --- |
| 连不上，报 Bad username/password | 用 `os`/`os`；凭据正确仍失败看端口是否写反（1883↔8883 组件会自动纠正并 WARN） |
| TLS 握手失败 | 8883 必须内嵌 EMQX CA（EMQX Cloud 控制台下载，EMBED_TXTFILES 嵌入）；未配 CA 仅限开发 |
| 平台上设备不在线 | 心跳周期 ≥ 60s；或 uplink 主题拼错 |
| 收不到下行指令 | 确认订阅的是 `device/{id}/downlink`，id 与平台一致；管理端可用「测试消息」按钮验证 |
| 升级指令解析不到 download_url | 信封较大会分片，组件已做重组（收缓冲 3072），自定义解析时必须按 `data` 层级取 `firmware.download_url` |

## Resources

- `references/iot-mqtt-protocol.md`：平台侧完整协议参考（连接信息、信封与各 type 报文格式、info 字段与别名、平台处理行为、EMQX 踩坑）。接入前必读。
- 组件源码：`E:\iot-platform\esp32\components\app_mqtt\`；平台侧文档：`E:\iot-platform\docs\MQTT.md`、`docs/INTEGRATION.md`。
